﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDb
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
            RefreshDataGridView();
        }
        int selectedRowId = -1;
        string delkeyword;
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells["Id"].Value != DBNull.Value)
            {
                // Get the ID of the selected row if the "Id" cell is not DBNull
                selectedRowId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Id"].Value);
                delkeyword = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells["Title"].Value);

                label3.Text = selectedRowId.ToString();

            }
            else
            {
                // Handle the case where the "Id" cell is DBNull
                MessageBox.Show("The selected row does not contain a valid ID.");
            }
        }


        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM  Assessment WHERE NOT title LIKE 'del%' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (selectedRowId == -1)
            {
                MessageBox.Show("Please select a row from the DataGridView.");
                return;
            }
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE Assessment SET Title = CONCAT('del', @delkeyword) WHERE Id = @selectedRowId", con);

            cmd.Parameters.AddWithValue("@delkeyword", delkeyword);
            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated");

            // Refresh DataGridView after update
            RefreshDataGridView();
            label3.Text = "?";


        }

        private void Form13_Load(object sender, EventArgs e)
        {

        }
    }
}
