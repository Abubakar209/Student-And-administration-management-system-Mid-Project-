﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace projectDb
{
    public partial class Form15 : Form
    {
        public Form15()
        {
            InitializeComponent();
            getRubricMeasurmentId();
            getAssessmentcmpId();
            getStudentId();
            RefreshDataGridView();

        }

        private void Form15_Load(object sender, EventArgs e)
        {
           /* getRubricMeasurmentId();
            getAssessmentcmpId();
            getStudentId();*/
        }


        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM  StudentResult", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }


        void getAssessmentcmpId()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT Id FROM AssessmentComponent WHERE NOT name LIKE 'del%'", con);


            SqlDataReader reader = cmd.ExecuteReader();

            // Clear existing items in the ComboBox
            comboBox2.Items.Clear();

            // Add Rubric Ids to the ComboBox
            while (reader.Read())
            {
                comboBox2.Items.Add(reader["Id"]);
            }

            reader.Close();


        }

        void getStudentId()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT Id FROM Student WHERE status=5", con);


            SqlDataReader reader = cmd.ExecuteReader();

            // Clear existing items in the ComboBox
            comboBox1.Items.Clear();

            // Add Rubric Ids to the ComboBox
            while (reader.Read())
            {
                comboBox1.Items.Add(reader["Id"]);
            }

            reader.Close();


        }

        void getRubricMeasurmentId()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT Id FROM RubricLevel WHERE NOT details LIKE 'del%'", con);


            SqlDataReader reader = cmd.ExecuteReader();

            // Clear existing items in the ComboBox
            comboBox3.Items.Clear();

            // Add Rubric Ids to the ComboBox
            while (reader.Read())
            {
                comboBox3.Items.Add(reader["Id"]);
            }

            reader.Close();


        }





        private void button1_Click(object sender, EventArgs e)
        {

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("INSERT INTO StudentResult (StudentId, AssessmentComponentId, RubricMeasurementId, EvaluationDate) " +
               "VALUES (@StudentId, @AssessmentComponentId, @RubricMeasurementId, @EvaluationDate)", con);

            cmd.Parameters.AddWithValue("@StudentId", comboBox1.Text);
            cmd.Parameters.AddWithValue("@AssessmentComponentId", comboBox2.Text);
            cmd.Parameters.AddWithValue("@RubricMeasurementId",comboBox3.Text);
            cmd.Parameters.AddWithValue("@EvaluationDate", dateTimePicker1.Value);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
            RefreshDataGridView();


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
