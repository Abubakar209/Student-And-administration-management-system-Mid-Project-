﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDb
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
            RefreshDataGridView();



        }






        private void Form14_Load(object sender, EventArgs e)
        {
            getRubricId();
            getAssessmentId();

        }


        void getRubricId()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT Id FROM Rubric WHERE NOT Details LIKE 'del%'", con);

               
                SqlDataReader reader = cmd.ExecuteReader();

                // Clear existing items in the ComboBox
                comboBox1.Items.Clear();

                // Add Rubric Ids to the ComboBox
                while (reader.Read())
                {
                    comboBox1.Items.Add(reader["Id"]);
                }

                reader.Close();
            
            
        

        }


        void getAssessmentId()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT Id FROM Assessment WHERE NOT title LIKE 'del%'", con);


            SqlDataReader reader = cmd.ExecuteReader();

            // Clear existing items in the ComboBox
            comboBox2.Items.Clear();

            // Add Rubric Ids to the ComboBox
            while (reader.Read())
            {
                comboBox2.Items.Add(reader["Id"]);
            }

            reader.Close();






        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Check if any field is null or empty
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(comboBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(comboBox2.Text))
            {
                MessageBox.Show("Please fill in all the fields.");
                return;
            }

            // Check if marks entered for Assessment Component are negative
            if (!int.TryParse(textBox2.Text, out int componentTotalMarks) || componentTotalMarks < 0)
            {
                MessageBox.Show("Total marks cannot be negative.");
                return;
            }

            var con = Configuration.getInstance().getConnection();

            // Fetch total marks of the selected assessment from the database
            int assessmentId = int.Parse(comboBox2.Text);
            int assessmentTotalMarks = GetAssessmentTotalMarks(assessmentId, con);

            // Fetch total marks of existing assessment components for the given assessment ID from the database
            int totalComponentMarks = GetTotalComponentMarksForAssessment(assessmentId, con);

            // Check if total marks entered for Assessment Component are not greater than the remaining marks of the assessment
         
            if (componentTotalMarks > (assessmentTotalMarks - totalComponentMarks))
            {
                MessageBox.Show("Total marks for Assessment Component cannot exceed the remaining marks of the assessment.");
               
                return;
            }

            SqlCommand cmd = new SqlCommand("INSERT INTO AssessmentComponent (name, RubricId, TotalMarks, DateCreated, DateUpdated, AssessmentId) " +
                "VALUES (@name, @RubricId, @TotalMarks, @DateCreated, @DateUpdated, @AssessmentId)", con);

            cmd.Parameters.AddWithValue("@name", textBox1.Text);
            cmd.Parameters.AddWithValue("@RubricId", int.Parse(comboBox1.Text));
            cmd.Parameters.AddWithValue("@TotalMarks", componentTotalMarks);
            cmd.Parameters.AddWithValue("@DateCreated", DateTime.Now);
            cmd.Parameters.AddWithValue("@DateUpdated", DateTime.Now);
            cmd.Parameters.AddWithValue("@AssessmentId", assessmentId);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
            RefreshDataGridView();
            // Clear textboxes after insertion
            textBox1.Text = string.Empty;
        }

        private int GetAssessmentTotalMarks(int assessmentId, SqlConnection connection)
        {
            SqlCommand cmd = new SqlCommand("SELECT totalmarks FROM Assessment WHERE Id = @assessmentId", connection);
            cmd.Parameters.AddWithValue("@assessmentId", assessmentId);
            object result = cmd.ExecuteScalar();
            return result == null ? 0 : (int)result;
        }

        private int GetTotalComponentMarksForAssessment(int assessmentId, SqlConnection connection)
        {
            SqlCommand cmd = new SqlCommand("SELECT SUM(TotalMarks) FROM AssessmentComponent WHERE AssessmentId = @assessmentId", connection);
            cmd.Parameters.AddWithValue("@assessmentId", assessmentId);
            object result = cmd.ExecuteScalar();
            return result == null || result == DBNull.Value ? 0 : (int)result;
        }
        int selectedRowId = -1;
        string delkeyword;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells["Id"].Value != DBNull.Value)
            {
                // Get the ID of the selected row if the "Id" cell is not DBNull
                selectedRowId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Id"].Value);
                delkeyword = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells["name"].Value);

                label6.Text = selectedRowId.ToString();

            }
        }
        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM  AssessmentComponent WHERE NOT AssessmentComponent.name LIKE 'del%' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
         
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Check if no row is selected
            if (selectedRowId == -1)
            {
                MessageBox.Show("Please select a row from the DataGridView.");
                return;
            }

            // Fetch the existing values of the AssessmentComponent from the database
            string existingName = "";
            int existingRubricId = 0;
            int existingTotalMarks = 0;

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT name, RubricId, TotalMarks FROM AssessmentComponent WHERE Id = @selectedRowId", con);
            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                existingName = reader["name"].ToString();
                existingRubricId = (int)reader["RubricId"];
                existingTotalMarks = (int)reader["TotalMarks"];
            }

            reader.Close();

            // Get new values from the form controls
            string newName = string.IsNullOrEmpty(textBox1.Text) ? existingName : textBox1.Text;
            int newRubricId = string.IsNullOrEmpty(comboBox1.Text) ? existingRubricId : int.Parse(comboBox1.Text);
            int newTotalMarks = string.IsNullOrEmpty(textBox2.Text) ? existingTotalMarks : int.Parse(textBox2.Text);

            // Check if new values are same as existing values
            if (newName == existingName && newRubricId == existingRubricId && newTotalMarks == existingTotalMarks)
            {
                MessageBox.Show("No changes to update.");
                return;
            }

            // Check if total marks for Assessment Component are negative
            if (newTotalMarks < 0)
            {
                MessageBox.Show("Total marks cannot be negative.");
                return;
            }

            // Fetch total marks of the selected assessment from the database
            int assessmentId = int.Parse(comboBox2.Text);
            int assessmentTotalMarks = GetAssessmentTotalMarks(assessmentId, con);

            // Fetch total marks of existing assessment components for the given assessment ID from the database
            int totalComponentMarks = GetTotalComponentMarksForAssessment(assessmentId, con);

            // Calculate remaining marks after considering existing and new total marks
            int remainingMarks = assessmentTotalMarks - totalComponentMarks + existingTotalMarks;

            // Check if total marks entered for Assessment Component exceed the remaining marks of the assessment
            if (newTotalMarks > remainingMarks)
            {
                MessageBox.Show("Total marks for Assessment Component cannot exceed the remaining marks of the assessment.");
                return;
            }

            // Perform the update if there are changes
            cmd = new SqlCommand("UPDATE AssessmentComponent SET name = @name, RubricId = @rubricId, TotalMarks = @totalMarks,DateUpdated=@DateUpdated WHERE Id = @selectedRowId", con);
            cmd.Parameters.AddWithValue("@name", newName);
            cmd.Parameters.AddWithValue("@rubricId", newRubricId);
            cmd.Parameters.AddWithValue("@totalMarks", newTotalMarks);
            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            cmd.Parameters.AddWithValue("@DateUpdated", DateTime.Now);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated");
            RefreshDataGridView();
            label6.Text = "?";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (selectedRowId == -1)
            {
                MessageBox.Show("Please select a row from the DataGridView.");
                return;
            }
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE AssessmentComponent SET Name = CONCAT('del', @delkeyword) WHERE Id = @selectedRowId", con);

            cmd.Parameters.AddWithValue("@delkeyword", delkeyword);
            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated");

            // Refresh DataGridView after update
            RefreshDataGridView();
            label6.Text = "?";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
