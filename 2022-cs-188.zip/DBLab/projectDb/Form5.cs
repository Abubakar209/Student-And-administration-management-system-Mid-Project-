﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDb
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            RefreshDataGridView();
        }
        private void Form5_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please provide the details to insert.");
                return;
            }

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("INSERT INTO Rubric (id,Details, CloId)  VALUES ((select count(*) + 1 from rubric),@Details, @CloId)", con);

            cmd.Parameters.AddWithValue("@Details", textBox1.Text);
            cmd.Parameters.AddWithValue("@CloId", selectedRowId);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");

            // Clear textboxes after insertion
            textBox1.Text = string.Empty;
            RefreshDataGridView();
        }

        int selectedRowId = -1;
        string delkeyword;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells["Id"].Value != DBNull.Value)
            {
                // Get the ID of the selected row if the "Id" cell is not DBNull
                selectedRowId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Id"].Value);
                

                label3.Text = selectedRowId.ToString();
            }
            else
            {
                // Handle the case where the "Id" cell is DBNull
                MessageBox.Show("The selected row does not contain a valid ID.");
            }
        }

        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT clo.Id FROM Clo    WHERE NOT name LIKE 'del%' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            label3.Text = "clo";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           Form7 form7 = new Form7();   
            form7.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.ShowDialog();
        }
    }
}
