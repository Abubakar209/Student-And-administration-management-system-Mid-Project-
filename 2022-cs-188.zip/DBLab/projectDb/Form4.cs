﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace projectDb
{
    public partial class Form4 : Form
    {
        private int selectedRowId = -1; // Initialize selectedRowId
        private string delkeyword;
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Clo WHERE NOT name LIKE 'del%'", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells["Id"].Value != DBNull.Value)
            {
                // Get the ID of the selected row
                selectedRowId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Id"].Value);
                delkeyword = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells["name"].Value);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Refresh DataGridView
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            




        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please provide the Name to insert");
                return;
            }

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("INSERT INTO Clo (Name, DateCreated, DateUpdated) VALUES (@Name, @DateCreated, @DateUpdated)", con);

            cmd.Parameters.AddWithValue("@Name", textBox1.Text);
            cmd.Parameters.AddWithValue("@DateCreated", DateTime.Now);
            cmd.Parameters.AddWithValue("@DateUpdated", DateTime.Now);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");

            // Clear textboxes after insertion
            textBox1.Text = string.Empty;

            // Refresh DataGridView after insertion
            RefreshDataGridView();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (selectedRowId == -1)
            {
                MessageBox.Show("Please select a row from the DataGridView.");
                return;
            }

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please provide the Name for updating.");
                return;
            }

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE Clo SET Name = @Name, DateUpdated = @DateUpdated WHERE Id = @selectedRowId", con);

            cmd.Parameters.AddWithValue("@Name", textBox1.Text);
            cmd.Parameters.AddWithValue("@DateUpdated", DateTime.Now);
            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated");

            // Clear textboxes after update
            textBox1.Text = string.Empty;

            // Refresh DataGridView after update
            RefreshDataGridView();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (selectedRowId == -1)
            {
                MessageBox.Show("Please select a row from the DataGridView.");
                return;
            }



            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE clo SET name = CONCAT('del', @delkeyword) WHERE Id = @selectedRowId", con);
            cmd.Parameters.AddWithValue("@delkeyword", delkeyword);
            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Deleted");

            // Clear textboxes after update
            textBox1.Text = string.Empty;

            // Refresh DataGridView after update
            RefreshDataGridView();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }
    }
}
