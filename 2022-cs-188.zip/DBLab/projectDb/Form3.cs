﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDb
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

       


        private void InitializeDataGridView()
        {
            gridView1.Rows.Clear();
            gridView1.DataSource = null; // Clear DataSource
            var con = Configuration.getInstance().getConnection();
            {

                var cmd = new SqlCommand("Select RegistrationNumber from Student", con);
                {

                    SqlDataAdapter sdata = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sdata.Fill(dt);
                    gridView1.DataSource = dt;
                    gridView1.Refresh();
                }
            }
            // Add columns to the DataGridView
            gridView1.Columns.Add(CreateButtonColumn("Present", "Present"));
            gridView1.Columns.Add(CreateButtonColumn("Absent", "Absent"));
            gridView1.Columns.Add(CreateButtonColumn("Leave", "Leave"));
            gridView1.Columns.Add(CreateButtonColumn("Late", "Late"));

        }
        private DataGridViewButtonColumn CreateButtonColumn(string name, string text)
        {
            DataGridViewButtonColumn column = new DataGridViewButtonColumn();
            column.Name = name;
            column.HeaderText = text;
            column.Text = text;
            column.UseColumnTextForButtonValue = true;
            return column;
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 1) // Exclude the RollNumber column
            {
                DataGridViewButtonCell buttonCell = gridView1.Rows[e.RowIndex].Cells[e.ColumnIndex] as DataGridViewButtonCell;
                if (buttonCell != null)
                {
                    var con = Configuration.getInstance().getConnection();
                    {
                        ;
                        string stRollNo = gridView1.Rows[e.RowIndex].Cells["RegistrationNumber"].Value.ToString();
                        int studentID = GetStudentID(con, stRollNo);
                        if (studentID == -1)
                        {
                            MessageBox.Show("Student not found.");
                            return;
                        }

                        string buttonText = buttonCell.Value.ToString();
                        var date = datepicker.Value;
                        int attendanceID = GetAttendanceID(con, date);
                        if (attendanceID == -1)
                        {
                            MessageBox.Show("Attendance record not found for the selected date.");
                            return;
                        }

                        int status = GetAttendanceStatus(buttonText);

                        InsertAttendanceRecord(con, studentID, attendanceID, status);

                        MessageBox.Show($"Button '{buttonText}' clicked for student with roll number '{gridView1.Rows[e.RowIndex].Cells["RegistrationNumber"].Value}'");
                    }
                }
            }
        }

        private int GetStudentID(SqlConnection connection, string registrationNumber)
        {
            using (var cmd = new SqlCommand("SELECT ID FROM Student WHERE RegistrationNumber = @registrationNumber", connection))
            {
                cmd.Parameters.AddWithValue("@registrationNumber", registrationNumber);
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    return Convert.ToInt32(result);
                }
                return -1; // Return -1 if no student is found
            }
        }

        private int GetAttendanceID(SqlConnection connection, DateTime date)
        {
            using (var cmd = new SqlCommand("SELECT ID FROM ClassAttendance WHERE CONVERT(date, AttendanceDate) = @date", connection))
            {
                cmd.Parameters.AddWithValue("@date", date.Date);
                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    return Convert.ToInt32(result);
                }
                return -1; // Return -1 if no attendance record is found for the date
            }
        }


        private int GetAttendanceStatus(string buttonText)
        {
            string lowerButtonText = buttonText.ToLower();

            if (lowerButtonText == "present")
            {
                return 1;
            }
            else if (lowerButtonText == "absent")
            {
                return 2;
            }
            else if (lowerButtonText == "leave")
            {
                return 3;
            }
            else if (lowerButtonText == "late")
            {
                return 4;
            }
            else
            {
                return 5; // Default status
            }
        }

        private void InsertAttendanceRecord(SqlConnection connection, int studentID, int attendanceID, int status)
        {
            using (var cmd = new SqlCommand("INSERT INTO StudentAttendance (AttendanceID, StudentID, AttendanceStatus) VALUES (@attendanceID, @studentID, @status)", connection))
            {
                cmd.Parameters.AddWithValue("@attendanceID", attendanceID);
                cmd.Parameters.AddWithValue("@studentID", studentID);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.ExecuteNonQuery();
            }
        }

        private void btnDate_Click_1(object sender, EventArgs e)
        {
            {
                DateTime date = datepicker.Value.Date; // Extract only the date portion
                gridView1.DataSource = null;
                gridView1.Refresh();
                var con = Configuration.getInstance().getConnection();
                {


                    var isAlready = new SqlCommand("SELECT AttendanceDate FROM ClassAttendance WHERE CONVERT(date, AttendanceDate) = @date", con);
                    {
                        isAlready.Parameters.AddWithValue("@date", date);
                        object result = isAlready.ExecuteScalar();

                        // If result is not null, it means the date exists in the database
                        if (result == null)
                        {
                            var cmd = new SqlCommand("INSERT INTO ClassAttendance (AttendanceDate) VALUES (@date)", con);
                            {
                                cmd.Parameters.AddWithValue("@date", date);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }

                   

                }
            }
            InitializeDataGridView();
            
        }

        private void dtpicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void gridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}