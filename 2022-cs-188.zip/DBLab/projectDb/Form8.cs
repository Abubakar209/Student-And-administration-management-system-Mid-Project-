﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDb
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
            RefreshDataGridView();
        }
        int selectedRowId = -1;
        

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label6.Text = comboBox1.Text;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) &&  selectedRowId<=-1)
            {
                MessageBox.Show("Please provide the details to insert.");
                return;
            }

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("INSERT INTO RubricLevel (Rubricid,Details,MeasurementLevel)  VALUES (@selectedRowId,@Details, @MeasurementLevel)", con);

            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            cmd.Parameters.AddWithValue("@Details", textBox1.Text);
            cmd.Parameters.AddWithValue("@MeasurementLevel", int.Parse(label6.Text));


            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");

            // Clear textboxes after insertion
            textBox1.Text = string.Empty;
           
            RefreshDataGridView();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells["RubricId"].Value != DBNull.Value)
            {
                // Get the ID of the selected row if the "Id" cell is not DBNull
                selectedRowId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["RubricId"].Value);
                label2.Text = selectedRowId.ToString();
            }
            else
            {
                // Handle the case where the "Id" cell is DBNull
                MessageBox.Show("The selected row does not contain a valid ID.");
            }
        }

        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT rubric.id as RubricId FROM  rubric WHERE NOT rubric.Details LIKE 'del%' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            label2.Text = "Id";
            label6.Text = "?";
            
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
           Form9 form9 = new Form9();
            form9.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form10 form10 = new Form10();   
            form10.ShowDialog();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }
    }
}
