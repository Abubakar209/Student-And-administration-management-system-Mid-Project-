﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDb
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
            RefreshDataGridView();
        }

        int selectedRowId = -1;
        string delkeyword;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells["RubricLevelId"].Value != DBNull.Value)
            {
                // Get the ID of the selected row if the "Id" cell is not DBNull
                selectedRowId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["RubricLevelId"].Value);
                delkeyword = Convert.ToString(dataGridView1.Rows[e.RowIndex].Cells["details"].Value);

                label3.Text = selectedRowId.ToString();
            }
            else
            {
                // Handle the case where the "Id" cell is DBNull
                MessageBox.Show("The selected row does not contain a valid ID.");
            }
        }


        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT rubriclevel.id as RubricLevelId,rubriclevel.Details,rubriclevel.MeasurementLevel FROM  rubricLevel WHERE NOT rubriclevel.Details LIKE 'del%' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            label3.Text = "Id";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (selectedRowId == -1)
            {
                MessageBox.Show("Please select a row from the DataGridView.");
                return;
            }

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("UPDATE RubricLevel SET Details = CONCAT('del', @delkeyword) WHERE Id = @selectedRowId", con);

            cmd.Parameters.AddWithValue("@delkeyword", delkeyword);
            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated");

            // Refresh DataGridView after update
            RefreshDataGridView();
        }
    }
}
