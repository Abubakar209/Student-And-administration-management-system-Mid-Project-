﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using System.Xml.Linq;
using System.Data.SqlClient;
using iTextSharp.text;

namespace projectDb
{
    public partial class Form16 : Form
    {
        public Form16()
        {
            InitializeComponent();
        }

        DataTable AssessmentWiseDataTable()
        {
            DataTable Ass = new DataTable();
            Ass.Columns.Add("Student name");
            Ass.Columns.Add("Assessment Title");
            Ass.Columns.Add("Marks Obtained");

            string query = "SELECT CONCAT(Student.FirstName, ' ', Student.LastName) AS [Student name], " +
                           "Assessment.Title AS [Assessment Title], " +
                           "SUM(RubricLevel.MeasurementLevel * AssessmentComponent.TotalMarks) / SUM(Assessment.TotalMarks) AS [Marks Obtained] " +
                           "FROM StudentResult " +
                           "INNER JOIN RubricLevel ON StudentResult.RubricMeasurementId = RubricLevel.Id " +
                           "INNER JOIN Rubric ON Rubric.Id = RubricLevel.RubricId " +
                           "INNER JOIN Clo ON Clo.Id = Rubric.CloId " +
                           "INNER JOIN AssessmentComponent ON AssessmentComponent.RubricId = Rubric.Id " +
                           "INNER JOIN Assessment ON Assessment.Id = AssessmentComponent.AssessmentId " +
                           "INNER JOIN Student ON StudentResult.StudentId = Student.Id " +
                           "GROUP BY CONCAT(Student.FirstName, ' ', Student.LastName), Assessment.Title";

            SqlCommand sqlcmd1 = new SqlCommand(query, Configuration.getInstance().getConnection());
            {
                SqlDataReader dr = sqlcmd1.ExecuteReader();
                {
                    while (dr.Read())
                    {
                        Ass.Rows.Add(dr["Student name"].ToString(), dr["Assessment Title"].ToString(), dr["Marks Obtained"].ToString());
                    }
                }
            }

            return Ass;
        }






        DataTable CloWiseDataTable()
        {
            DataTable CLO = new DataTable();
            CLO.Columns.Add("Student Name");
            CLO.Columns.Add("CLO Name");
            CLO.Columns.Add("Marks Obtained");

            string query = "SELECT CONCAT(Student.FirstName, ' ', Student.LastName) AS [Student Name], Clo.Name AS [CLO Name], " +
                           "SUM((RubricLevel.MeasurementLevel * AssessmentComponent.TotalMarks) / 4) AS [ObtainedMarks] " +
                           "FROM StudentResult " +
                           "INNER JOIN RubricLevel ON StudentResult.RubricMeasurementId = RubricLevel.Id " +
                           "INNER JOIN Rubric ON Rubric.Id = RubricLevel.RubricId " +
                           "INNER JOIN Clo ON Clo.Id = Rubric.CloId " +
                           "INNER JOIN AssessmentComponent ON AssessmentComponent.RubricId = Rubric.Id " +
                           "INNER JOIN Student ON StudentResult.StudentId = Student.Id " +
                           "GROUP BY CONCAT(Student.FirstName, ' ', Student.LastName), Clo.Name";

            SqlCommand sqlcmd = new SqlCommand(query, Configuration.getInstance().getConnection());
            {
                SqlDataReader dr = sqlcmd.ExecuteReader();
                {
                    while (dr.Read())
                    {
                        CLO.Rows.Add(dr["Student Name"].ToString(), dr["CLO Name"].ToString(), dr["ObtainedMarks"].ToString());
                    }
                }
            }

            return CLO;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreatePdfFromDataTable("report", CloWiseDataTable());
        }


        private void CreatePdfFromDataTable(string title, DataTable dataTable)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PDF files (.pdf)|.pdf";
            saveFileDialog.Title = "Export to PDF";
            saveFileDialog.FileName = title;
            saveFileDialog.ShowDialog();

            if (saveFileDialog.FileName != "")
            {
                Document document = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
                iTextSharp.text.pdf.PdfWriter.GetInstance(document, new FileStream(saveFileDialog.FileName, FileMode.Create));
                document.Open();
                Paragraph heading = new Paragraph(title, FontFactory.GetFont("Arial", 20));
                heading.Alignment = Element.ALIGN_CENTER;
                document.Add(heading);
                document.Add(new iTextSharp.text.Chunk("\n"));

                iTextSharp.text.pdf.PdfPTable pdfTable = new iTextSharp.text.pdf.PdfPTable(dataTable.Columns.Count);
                pdfTable.DefaultCell.Padding = 3;
                pdfTable.WidthPercentage = 100;
                pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;

                foreach (DataColumn column in dataTable.Columns)
                {
                    iTextSharp.text.pdf.PdfPCell cell = new iTextSharp.text.pdf.PdfPCell(new Phrase(column.ColumnName));
                    pdfTable.AddCell(cell);
                }

                foreach (DataRow row in dataTable.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        string cellText = item != null ? item.ToString() : "";
                        pdfTable.AddCell(cellText);
                    }
                }

                document.Add(pdfTable);

                document.Close();

                MessageBox.Show("PDF file has been created!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CreatePdfFromDataTable("report", AssessmentWiseDataTable());
            

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form16_Load(object sender, EventArgs e)
        {

        }

        DataTable StudentListDataTable()
        {
            DataTable studentList = new DataTable();
            studentList.Columns.Add("Student Name");
            studentList.Columns.Add("Active");
            studentList.Columns.Add("Inactive");

            
            string query = "SELECT CONCAT(FirstName, ' ', LastName) AS StudentName, " +
                           "(CASE WHEN Status = 5 THEN 1 ELSE 0 END) AS IsActive " +
                           "FROM Student";

            
            SqlConnection connection = Configuration.getInstance().getConnection();
            {

                SqlCommand sqlCommand = new SqlCommand(query, connection);
                SqlDataReader reader = sqlCommand.ExecuteReader();

                // Dictionary to hold active and inactive counts for each student
                Dictionary<string, int[]> studentStatus = new Dictionary<string, int[]>();

                // Loop through the result set and populate the dictionary
                while (reader.Read())
                {
                    string studentName = reader["StudentName"].ToString();
                    int isActive = Convert.ToInt32(reader["IsActive"]);

                    if (!studentStatus.ContainsKey(studentName))
                    {
                        studentStatus[studentName] = new int[2] { 0, 0 }; // Index 0: Active, Index 1: Inactive
                    }

                    studentStatus[studentName][isActive]++;
                }

                
                foreach (var pair in studentStatus)
                {
                    studentList.Rows.Add(pair.Key, pair.Value[1], pair.Value[0]);
                }

                
                int totalStudents = studentStatus.Keys.Count;
                int activeStudents = studentStatus.Values.Sum(counts => counts[1]);
                int inactiveStudents = studentStatus.Values.Sum(counts => counts[0]);

               
                studentList.Rows.Add("Total", activeStudents, inactiveStudents);
            }

            return studentList;
        }

        DataTable AttendanceListDataTable()
        {
            DataTable attendanceList = new DataTable();
            attendanceList.Columns.Add("Date");
            attendanceList.Columns.Add("Total Students Present");


            string query = "SELECT CONVERT(date, CA.AttendanceDate) AS AttendanceDate, COUNT(SA.StudentId) AS TotalStudentsPresent " +
                           "FROM ClassAttendance CA " +
                           "LEFT JOIN StudentAttendance SA ON CA.Id = SA.AttendanceId " +
                           "GROUP BY CONVERT(date, CA.AttendanceDate)";


            SqlConnection connection = Configuration.getInstance().getConnection();
            {
                SqlCommand sqlCommand = new SqlCommand(query, connection);
                SqlDataReader reader = sqlCommand.ExecuteReader();


                while (reader.Read())
                {
                    string attendanceDate = reader["AttendanceDate"].ToString();
                    int totalStudentsPresent = Convert.ToInt32(reader["TotalStudentsPresent"]);

                    attendanceList.Rows.Add(attendanceDate, totalStudentsPresent);
                }
            }

            return attendanceList;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CreatePdfFromDataTable("report", StudentListDataTable());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CreatePdfFromDataTable("report", AttendanceListDataTable());
        }
    }
}
