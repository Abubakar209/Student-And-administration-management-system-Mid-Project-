﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDb
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
            RefreshDataGridView();
        }
        int selectedRowId = -1;
        
      
        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT rubriclevel.id as RubricLevelId,rubriclevel.Details,rubriclevel.MeasurementLevel FROM  rubricLevel WHERE NOT rubriclevel.Details LIKE 'del%' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            label3.Text = "Id";
        }
        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (selectedRowId == -1)
            {
                MessageBox.Show("Please select a row from the DataGridView.");
                return;
            }

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please provide the details for updating.");
                return;
            }

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd;
            if (string.IsNullOrEmpty(label6.Text) || !int.TryParse(label6.Text, out int measurementLevel))
            {
                // If the combo box value is not selected or not a valid integer, update only the Details field
                cmd = new SqlCommand("UPDATE RubricLevel SET Details = @Details WHERE Id = @selectedRowId", con);
                cmd.Parameters.AddWithValue("@Details", textBox1.Text);
            }
            else
            {
                // If the combo box value is selected and a valid integer, update both Details and MeasurementLevel fields
                cmd = new SqlCommand("UPDATE RubricLevel SET Details = @Details, MeasurementLevel = @MeasurementLevel WHERE Id = @selectedRowId", con);
                cmd.Parameters.AddWithValue("@Details", textBox1.Text);
                cmd.Parameters.AddWithValue("@MeasurementLevel", measurementLevel);
            }

            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated");

            // Refresh DataGridView after update
            RefreshDataGridView();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label6.Text = comboBox1.Text;
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells["RubricLevelId"].Value != DBNull.Value)
            {
                // Get the ID of the selected row if the "Id" cell is not DBNull
                selectedRowId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["RubricLevelId"].Value);
              label3.Text=  selectedRowId.ToString();
            }
            else
            {
                // Handle the case where the "Id" cell is DBNull
                MessageBox.Show("The selected row does not contain a valid ID.");
            }

            
        }
    }
}
