﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace projectDb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
           

           
        }


        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Insert into Student values " +
                "( @FirstName, @LastName,@Contact,@Email,@RegistrationNumber,@Status)", con);

            cmd.Parameters.AddWithValue("@FirstName", textBox2.Text);
            cmd.Parameters.AddWithValue("@LastName", textBox3.Text);
            cmd.Parameters.AddWithValue("@Contact", textBox4.Text);
            cmd.Parameters.AddWithValue("@Email", textBox5.Text);
            cmd.Parameters.AddWithValue("@RegistrationNumber", textBox6.Text);
            cmd.Parameters.AddWithValue("@Status", textBox7.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully saved");
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            String registrationNumber = textBox6.Text;

            // Construct the SQL command to update the status of the student
            SqlCommand cmd = new SqlCommand("UPDATE Student SET" +
                " Status = @Status WHERE RegistrationNumber = @RegistrationNumber", con);
            cmd.Parameters.AddWithValue("@Status", 6); // Set the status to 'inactive'
            cmd.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);

            // Execute the UPDATE command
            int rowsAffected = cmd.ExecuteNonQuery();

            if (rowsAffected > 0)
            {
                MessageBox.Show("Status updated successfully.");
            }
            else
            {
                MessageBox.Show("No student found with the provided registration number.");
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            // Check if RegistrationNumber is provided
            if (string.IsNullOrEmpty(textBox6.Text))
            {
                MessageBox.Show("Please provide the Registration Number for updating.");
                return;
            }

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd;
            string query = "UPDATE Student SET ";

            // Check each field and add it to the query if it's provided
            List<string> fieldsToUpdate = new List<string>();
            if (!string.IsNullOrEmpty(textBox2.Text))
                fieldsToUpdate.Add("FirstName = @FirstName");
            if (!string.IsNullOrEmpty(textBox3.Text))
                fieldsToUpdate.Add("LastName = @LastName");
            if (!string.IsNullOrEmpty(textBox4.Text))
                fieldsToUpdate.Add("Contact = @Contact");
            if (!string.IsNullOrEmpty(textBox5.Text))
                fieldsToUpdate.Add("Email = @Email");
            if (!string.IsNullOrEmpty(textBox7.Text))
                fieldsToUpdate.Add("Status = @Status");

            // Check if any field to update is provided
            if (fieldsToUpdate.Count == 0)
            {
                MessageBox.Show("Please provide at least one field to update.");
                return;
            }

            // Append fields to the query
            query += string.Join(", ", fieldsToUpdate);

            // Append WHERE clause
            query += " WHERE RegistrationNumber = @RegistrationNumber";

            // Create command and parameters
            cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@RegistrationNumber", textBox6.Text);

            if (!string.IsNullOrEmpty(textBox2.Text))
                cmd.Parameters.AddWithValue("@FirstName", textBox2.Text);
            if (!string.IsNullOrEmpty(textBox3.Text))
                cmd.Parameters.AddWithValue("@LastName", textBox3.Text);
            if (!string.IsNullOrEmpty(textBox4.Text))
                cmd.Parameters.AddWithValue("@Contact", textBox4.Text);
            if (!string.IsNullOrEmpty(textBox5.Text))
                cmd.Parameters.AddWithValue("@Email", textBox5.Text);
            if (!string.IsNullOrEmpty(textBox7.Text))
                cmd.Parameters.AddWithValue("@Status", textBox7.Text);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated");
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Student WHERE Status <> @statusDeleted", con);
            cmd.Parameters.AddWithValue("@statusDeleted", 6); // Assuming 6 represents an inactive student

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
           
        }
    }
}
