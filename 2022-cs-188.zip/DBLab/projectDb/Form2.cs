﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace projectDb
{
    public partial class Form2 : Form
    {


        public Form2()
        {
            InitializeComponent();
            updateGrd();




        }
        DateTime pickedDate;



        void updateGrd()
        {
            var con = Configuration.getInstance().getConnection();

            SqlCommand cmd = new SqlCommand("SELECT s.FirstName, s.LastName, s.RegistrationNumber,sa.AttendanceStatus " +
                                       "FROM Student s " +
                                       "JOIN StudentAttendance sa ON s.Id = sa.StudentID " +
                                       "WHERE s.Status = 5", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        int fnIdReturn()
        {
            if (!string.IsNullOrEmpty(label1.Text)) // Check if label1.Text is not empty
            {
                var con = Configuration.getInstance().getConnection();

                SqlCommand cmd = new SqlCommand("SELECT Id FROM Student WHERE Status = 5 AND RegistrationNumber = @RegistrationNumber", con);
                cmd.Parameters.AddWithValue("@RegistrationNumber", label1.Text);



                // Execute the command and return the result
                object result = cmd.ExecuteScalar();

                // Check if the result is not null and convert it to an integer
                if (result != null)
                {
                    return Convert.ToInt32(result);
                }
                else
                {

                    return -1;
                }

            }
            else
            {

                return -1;
            }
        }

        int GetClassAttendanceID(DateTime pickedDate)
        {
            var con = Configuration.getInstance().getConnection();



            SqlCommand cmd = new SqlCommand("SELECT Id FROM ClassAttendance WHERE AttendanceDate = @PickedDate", con);
            cmd.Parameters.AddWithValue("@PickedDate", pickedDate.Date); // Ensure we compare only the date part

            object result = cmd.ExecuteScalar(); // Execute the query and retrieve the result


            if (result != null)
            {
                return Convert.ToInt32(result);
            }
            else
            {

                return -1;
            }

        }







        private void button1_Click(object sender, EventArgs e)
        {

            var con = Configuration.getInstance().getConnection();

            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM ClassAttendance" +
                " WHERE AttendanceDate = @Date", con);
            cmd.Parameters.AddWithValue("@Date", dateTimePicker1.Value.Date);
            int count = (int)cmd.ExecuteScalar();

            if (count == 0)
            {
                cmd = new SqlCommand("INSERT INTO ClassAttendance (AttendanceDate) VALUES (@Date)", con);
                cmd.Parameters.AddWithValue("@Date", dateTimePicker1.Value.Date);

                cmd.ExecuteNonQuery();
                pickedDate = dateTimePicker1.Value;
                MessageBox.Show("Attendance marked for " + pickedDate.ToShortDateString());
            }
            else
            {
                MessageBox.Show("Attendance already marked for " + dateTimePicker1.Value.ToShortDateString());
            }




        }
        class model
        {
            int IdOfStudent;
            int status;
        }
        // create class attendance
        // get  class attendance Id
        // create studentAttendace for each model, (StudentId, AttendanceId, status)

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "Select" && e.RowIndex >= 0)
            {
                // Get the value of the "RegistrationNumber" column from the clicked row
                string registrationNumber = dataGridView1.Rows[e.RowIndex].Cells["RegistrationNumber"].Value.ToString();

                // Display the registration number in Label1
                label1.Text = registrationNumber;
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void Name_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
