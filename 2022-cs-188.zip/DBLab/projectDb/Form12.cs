﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projectDb
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
            RefreshDataGridView();
        }
        int selectedRowId = -1;


        private void RefreshDataGridView()
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM  Assessment WHERE NOT title LIKE 'del%' ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Rows[e.RowIndex].Cells["Id"].Value != DBNull.Value)
            {
                // Get the ID of the selected row if the "Id" cell is not DBNull
                selectedRowId = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Id"].Value);
                label5.Text=selectedRowId.ToString();
               
            }
            else
            {
                // Handle the case where the "Id" cell is DBNull
                MessageBox.Show("The selected row does not contain a valid ID.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (selectedRowId == -1)
            {
                MessageBox.Show("Please select a row from the DataGridView.");
                return;
            }

            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("SELECT title, totalmarks, TotalWeightage FROM Assessment WHERE Id = @selectedRowId", con);
            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);
            SqlDataReader reader = cmd.ExecuteReader();

            // Get the existing values from the database
            string existingTitle = "";
            int existingTotalMarks = 0;
            int existingTotalWeightage = 0;

            if (reader.Read())
            {
                existingTitle = reader["title"].ToString();
                existingTotalMarks = (int)reader["totalmarks"];
                existingTotalWeightage = (int)reader["TotalWeightage"];
            }

            reader.Close();

            // Check if the new values are different from the existing values
            string newTitle = string.IsNullOrEmpty(textBox1.Text) ? existingTitle : textBox1.Text;
            int newTotalMarks = string.IsNullOrEmpty(textBox2.Text) ? existingTotalMarks : int.Parse(textBox2.Text);
            int newTotalWeightage = string.IsNullOrEmpty(textBox3.Text) ? existingTotalWeightage : int.Parse(textBox3.Text);

            if (newTitle == existingTitle && newTotalMarks == existingTotalMarks && newTotalWeightage == existingTotalWeightage)
            {
                MessageBox.Show("No changes to update.");
                return;
            }

            // Perform the update if there are changes
            cmd = new SqlCommand("UPDATE Assessment SET title = @title, totalmarks = @totalmarks, TotalWeightage = @totalweightage WHERE Id = @selectedRowId", con);
            cmd.Parameters.AddWithValue("@title", newTitle);
            cmd.Parameters.AddWithValue("@totalmarks", newTotalMarks);
            cmd.Parameters.AddWithValue("@totalweightage", newTotalWeightage);
            cmd.Parameters.AddWithValue("@selectedRowId", selectedRowId);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated");
            RefreshDataGridView();
            label5.Text = "?";
        }

        private void Form12_Load(object sender, EventArgs e)
        {

        }
    }
}
